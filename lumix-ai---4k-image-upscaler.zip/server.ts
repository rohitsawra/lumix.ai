import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import multer from 'multer';
import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import Replicate from 'replicate';
import dotenv from 'dotenv';
import cors from 'cors';

import sharp from 'sharp';

dotenv.config();

console.log('REPLICATE_API_TOKEN is set:', !!process.env.REPLICATE_API_TOKEN);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'public', 'uploads');
const enhancedDir = path.join(__dirname, 'public', 'enhanced');
[uploadsDir, enhancedDir].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(uploadsDir));
app.use('/enhanced', express.static(enhancedDir));

// Cleanup task: Delete files older than 1 hour every hour
setInterval(() => {
  const now = Date.now();
  const oneHour = 60 * 60 * 1000;

  [uploadsDir, enhancedDir].forEach(dir => {
    fs.readdir(dir, (err, files) => {
      if (err) return;
      files.forEach(file => {
        const filePath = path.join(dir, file);
        fs.stat(filePath, (err, stats) => {
          if (err) return;
          if (now - stats.mtimeMs > oneHour) {
            fs.unlink(filePath, () => {});
          }
        });
      });
    });
  });
}, 60 * 60 * 1000);

// Configure Multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit for upload
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPG, PNG and WEBP are allowed.'));
    }
  },
});

// Replicate client
const replicate = process.env.REPLICATE_API_TOKEN 
  ? new Replicate({ auth: process.env.REPLICATE_API_TOKEN })
  : null;

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

app.post('/api/enhance', upload.single('image'), async (req: any, res: express.Response) => {
  console.log('POST /api/enhance received');
  try {
    const file = req.file;
    if (!file) {
      return res.status(400).json({ error: 'No image uploaded' });
    }

    const mode = req.body.mode || 'base';
    const scale = parseInt(req.body.scale) || 2;

    // Try Replicate first if token is available
    if (process.env.REPLICATE_API_TOKEN) {
      try {
        console.log(`Attempting Replicate enhancement for ${file.filename}`);
        const replicateClient = new Replicate({ auth: process.env.REPLICATE_API_TOKEN });
        const imageBuffer = fs.readFileSync(file.path);
        const base64Image = `data:${file.mimetype};base64,${imageBuffer.toString('base64')}`;

        const output = await replicateClient.run(
          "nightmareai/real-esrgan",
          {
            input: {
              image: base64Image,
              upscale: scale,
              face_enhance: mode === 'realistic',
            }
          }
        );

        console.log('Replicate enhancement successful');
        return res.json({ 
          originalUrl: `/uploads/${file.filename}`,
          enhancedUrl: output,
          success: true,
          method: 'ai'
        });
      } catch (replicateError: any) {
        console.error('Replicate failed, falling back to Sharp:', replicateError.message);
        // Continue to fallback
      }
    } else {
      console.log('REPLICATE_API_TOKEN missing, using Sharp fallback');
    }

    // Sharp Fallback
    console.log(`Starting Sharp fallback for ${file.filename}`);
    const enhancedFilename = `enhanced-${file.filename}`;
    const enhancedPath = path.join(enhancedDir, enhancedFilename);
    
    const metadata = await sharp(file.path).metadata();
    const targetWidth = (metadata.width || 0) * scale;
    
    await sharp(file.path)
      .resize({
        width: targetWidth,
        kernel: mode === 'sharp' ? sharp.kernel.lanczos3 : sharp.kernel.mitchell
      })
      .sharpen(mode === 'sharp' ? 1.5 : 0.5)
      .toFile(enhancedPath);

    console.log('Sharp enhancement successful');
    res.json({
      originalUrl: `/uploads/${file.filename}`,
      enhancedUrl: `/enhanced/${enhancedFilename}`,
      success: true,
      method: 'fallback',
      message: 'Using standard upscaling (AI credits exhausted or token missing)'
    });

  } catch (error: any) {
    console.error('Enhancement error:', error);
    res.status(500).json({ error: error.message || 'Failed to enhance image' });
  }
});

// Global error handler for API routes
app.use('/api', (err: any, req: any, res: any, next: any) => {
  console.error('API Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error',
    code: err.code
  });
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
