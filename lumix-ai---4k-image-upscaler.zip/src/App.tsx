import React, { useState, useCallback, useRef } from 'react';
import { 
  Upload, 
  Image as ImageIcon, 
  Download, 
  RefreshCw, 
  Zap, 
  Maximize, 
  Sparkles, 
  AlertCircle,
  ChevronRight,
  Github,
  Twitter,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

type EnhancementMode = 'base' | 'sharp' | 'realistic';
type EnhancementScale = 2 | 4;

interface EnhancementResult {
  originalUrl: string;
  enhancedUrl: string;
  method?: 'ai' | 'fallback';
  message?: string;
}

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<EnhancementResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<EnhancementMode>('base');
  const [scale, setScale] = useState<EnhancementScale>(2);
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      processFile(selectedFile);
    }
  };

  const processFile = (selectedFile: File) => {
    if (!selectedFile.type.startsWith('image/')) {
      setError('Please upload an image file (JPG, PNG, or WEBP).');
      return;
    }
    setFile(selectedFile);
    setPreviewUrl(URL.createObjectURL(selectedFile));
    setResult(null);
    setError(null);
  };

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile) {
      processFile(droppedFile);
    }
  }, []);

  const handleEnhance = async () => {
    if (!file) return;

    setIsProcessing(true);
    setError(null);

    const formData = new FormData();
    formData.append('image', file);
    formData.append('mode', mode);
    formData.append('scale', scale.toString());

    try {
      const response = await fetch('/api/enhance', {
        method: 'POST',
        body: formData,
      });

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text();
        console.error('Non-JSON response received:', text);
        throw new Error(`Server returned an unexpected response format (${response.status}). Please check if the server is running correctly.`);
      }

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to enhance image');
      }

      setResult({
        originalUrl: data.originalUrl,
        enhancedUrl: data.enhancedUrl,
      });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = async () => {
    if (!result) return;
    try {
      const response = await fetch(result.enhancedUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `enhanced-${file?.name || 'image'}.png`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      console.error('Download failed', err);
    }
  };

  const reset = () => {
    setFile(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Header */}
      <header className="border-b border-zinc-800/50 bg-zinc-950/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center shadow-lg shadow-brand-500/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">Lumix<span className="text-brand-500">AI</span></span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">Pricing</a>
            <a href="#" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">API</a>
            <a href="#" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">Showcase</a>
          </nav>
          <div className="flex items-center gap-3">
            <button className="p-2 text-zinc-400 hover:text-white transition-colors">
              <Github className="w-5 h-5" />
            </button>
            <button className="px-4 py-2 bg-white text-zinc-950 rounded-full text-sm font-semibold hover:bg-zinc-200 transition-colors">
              Get Started
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-12 flex flex-col items-center">
        {/* Hero Section */}
        {!file && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12 max-w-2xl"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 tracking-tight leading-tight">
              Upscale your images to <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-brand-600">4K resolution</span>
            </h1>
            <p className="text-zinc-400 text-lg mb-8">
              Professional-grade AI image enhancement. Restore details, remove noise, and upscale your photos in seconds.
            </p>
          </motion.div>
        )}

        {/* Main Interface */}
        <div className="w-full max-w-4xl">
          <AnimatePresence mode="wait">
            {!file ? (
              <motion.div
                key="upload"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
                className={cn(
                  "relative group cursor-pointer border-2 border-dashed rounded-3xl p-12 flex flex-col items-center justify-center transition-all duration-300 min-h-[400px]",
                  isDragging 
                    ? "border-brand-500 bg-brand-500/5" 
                    : "border-zinc-800 hover:border-zinc-700 hover:bg-zinc-900/50"
                )}
              >
                <input 
                  type="file" 
                  className="hidden" 
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/jpeg,image/png,image/webp"
                />
                
                <div className="w-20 h-20 bg-zinc-900 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Upload className={cn("w-10 h-10 transition-colors", isDragging ? "text-brand-500" : "text-zinc-500")} />
                </div>
                
                <h3 className="text-xl font-semibold mb-2">Drop your image here</h3>
                <p className="text-zinc-500 text-center max-w-xs">
                  Supports JPG, PNG, and WEBP. Max file size 10MB.
                </p>

                <div className="mt-8 flex items-center gap-4 text-xs text-zinc-600 font-mono">
                  <span className="px-2 py-1 bg-zinc-900 rounded border border-zinc-800">4K READY</span>
                  <span className="px-2 py-1 bg-zinc-900 rounded border border-zinc-800">AI POWERED</span>
                  <span className="px-2 py-1 bg-zinc-900 rounded border border-zinc-800">NO LOSS</span>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="preview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                {/* Preview Area */}
                <div className="relative rounded-3xl overflow-hidden bg-zinc-900 border border-zinc-800 aspect-video flex items-center justify-center group">
                  {result ? (
                    <div className="relative w-full h-full select-none overflow-hidden">
                      {/* Enhanced Image (Background) */}
                      <img 
                        src={result.enhancedUrl} 
                        alt="Enhanced" 
                        className="w-full h-full object-contain"
                        referrerPolicy="no-referrer"
                      />
                      
                      {/* Original Image (Foreground with Clip) */}
                      <div 
                        className="absolute inset-0 overflow-hidden pointer-events-none"
                        style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
                      >
                        <img 
                          src={previewUrl!} 
                          alt="Original" 
                          className="w-full h-full object-contain grayscale-[0.5] brightness-[0.8]"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      {/* Slider Handle */}
                      <div 
                        className="absolute inset-y-0 w-1 bg-white cursor-ew-resize z-10 flex items-center justify-center"
                        style={{ left: `${sliderPosition}%` }}
                      >
                        <div className="w-8 h-8 bg-white rounded-full shadow-xl flex items-center justify-center -ml-0.5">
                          <div className="flex gap-0.5">
                            <div className="w-0.5 h-3 bg-zinc-400 rounded-full" />
                            <div className="w-0.5 h-3 bg-zinc-400 rounded-full" />
                          </div>
                        </div>
                        
                        {/* Labels */}
                        <div className="absolute top-4 right-6 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase text-white pointer-events-none">
                          Before
                        </div>
                        <div className="absolute top-4 left-6 bg-brand-500/50 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase text-white pointer-events-none">
                          After
                        </div>
                      </div>

                      {/* Invisible Input for Slider Control */}
                      <input 
                        type="range" 
                        min="0" 
                        max="100" 
                        value={sliderPosition} 
                        onChange={(e) => setSliderPosition(parseInt(e.target.value))}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
                      />
                    </div>
                  ) : (
                    <div className="relative w-full h-full">
                      <img 
                        src={previewUrl!} 
                        alt="Preview" 
                        className={cn(
                          "w-full h-full object-contain transition-all duration-500",
                          isProcessing ? "blur-sm opacity-50 scale-95" : ""
                        )}
                        referrerPolicy="no-referrer"
                      />
                      
                      {isProcessing && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center">
                          <div className="relative">
                            <RefreshCw className="w-12 h-12 text-brand-500 animate-spin" />
                            <motion.div 
                              initial={{ scale: 0.8, opacity: 0 }}
                              animate={{ scale: 1.2, opacity: 1 }}
                              transition={{ repeat: Infinity, repeatType: "reverse", duration: 1 }}
                              className="absolute inset-0 bg-brand-500/20 blur-xl rounded-full"
                            />
                          </div>
                          <p className="mt-4 font-medium text-brand-400 animate-pulse">Upscaling to 4K...</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Controls */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {result?.method === 'fallback' && (
                    <div className="md:col-span-3 p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center gap-3 text-amber-400 text-sm">
                      <Info className="w-5 h-5 shrink-0" />
                      <p>{result.message || 'Using standard upscaling (AI credits exhausted or token missing)'}</p>
                    </div>
                  )}
                  <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl space-y-4">
                    <div className="flex items-center gap-2 text-zinc-400 text-sm font-medium">
                      <Zap className="w-4 h-4" />
                      <span>Enhancement Mode</span>
                    </div>
                    <div className="flex flex-col gap-2">
                      {(['base', 'sharp', 'realistic'] as EnhancementMode[]).map((m) => (
                        <button
                          key={m}
                          onClick={() => setMode(m)}
                          disabled={isProcessing}
                          className={cn(
                            "px-4 py-2 rounded-xl text-sm font-medium transition-all text-left flex items-center justify-between",
                            mode === m 
                              ? "bg-brand-500 text-white shadow-lg shadow-brand-500/20" 
                              : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
                          )}
                        >
                          <span className="capitalize">{m}</span>
                          {mode === m && <ChevronRight className="w-4 h-4" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl space-y-4">
                    <div className="flex items-center gap-2 text-zinc-400 text-sm font-medium">
                      <Maximize className="w-4 h-4" />
                      <span>Upscale Factor</span>
                    </div>
                    <div className="flex gap-2">
                      {([2, 4] as EnhancementScale[]).map((s) => (
                        <button
                          key={s}
                          onClick={() => setScale(s)}
                          disabled={isProcessing}
                          className={cn(
                            "flex-1 py-3 rounded-xl text-sm font-bold transition-all",
                            scale === s 
                              ? "bg-brand-500 text-white shadow-lg shadow-brand-500/20" 
                              : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700"
                          )}
                        >
                          {s}X
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider">
                      Target: {scale === 2 ? '2K (2560px)' : '4K (3840px)'}
                    </p>
                  </div>

                  <div className="flex flex-col gap-3">
                    {!result ? (
                      <button
                        onClick={handleEnhance}
                        disabled={isProcessing}
                        className="flex-1 bg-white text-zinc-950 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-zinc-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-white/5"
                      >
                        {isProcessing ? (
                          <>
                            <RefreshCw className="w-5 h-5 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-5 h-5" />
                            Enhance Now
                          </>
                        )}
                      </button>
                    ) : (
                      <button
                        onClick={handleDownload}
                        className="flex-1 bg-brand-500 text-white rounded-2xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-brand-600 transition-all shadow-xl shadow-brand-500/20"
                      >
                        <Download className="w-5 h-5" />
                        Download 4K
                      </button>
                    )}
                    
                    <button
                      onClick={reset}
                      disabled={isProcessing}
                      className="py-3 bg-zinc-800 text-zinc-400 rounded-2xl font-medium text-sm hover:bg-zinc-700 transition-all"
                    >
                      Upload Different Image
                    </button>
                  </div>
                </div>

                {error && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-3 text-red-400 text-sm"
                  >
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    <div>
                      <p className="font-semibold">Enhancement Failed</p>
                      <p className="opacity-80">{error}</p>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Features Grid */}
        {!file && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24 w-full">
            {[
              {
                icon: <Zap className="w-6 h-6 text-brand-400" />,
                title: "Real-ESRGAN Powered",
                desc: "Uses state-of-the-art deep learning models to reconstruct lost details and textures."
              },
              {
                icon: <Maximize className="w-6 h-6 text-brand-400" />,
                title: "4K Resolution",
                desc: "Upscale your images up to 4x their original size without losing clarity or sharpness."
              },
              {
                icon: <Sparkles className="w-6 h-6 text-brand-400" />,
                title: "Noise Reduction",
                desc: "Automatically removes JPEG artifacts and sensor noise while preserving natural edges."
              }
            ].map((feature, i) => (
              <div key={i} className="p-8 rounded-3xl bg-zinc-900/50 border border-zinc-800/50 hover:border-zinc-700 transition-colors">
                <div className="w-12 h-12 bg-zinc-800 rounded-xl flex items-center justify-center mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
                <p className="text-zinc-500 text-sm leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/50 py-12 bg-zinc-950">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-brand-500" />
            <span className="font-bold text-lg tracking-tight">Lumix<span className="text-brand-500">AI</span></span>
          </div>
          
          <div className="flex items-center gap-8 text-sm text-zinc-500">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-zinc-500 hover:text-white transition-colors">
              <Twitter className="w-5 h-5" />
            </button>
            <button className="p-2 text-zinc-500 hover:text-white transition-colors">
              <Github className="w-5 h-5" />
            </button>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 mt-8 pt-8 border-t border-zinc-800/30 text-center text-zinc-600 text-xs">
          © 2026 Lumix AI. Powered by Real-ESRGAN and Replicate.
        </div>
      </footer>
    </div>
  );
}
